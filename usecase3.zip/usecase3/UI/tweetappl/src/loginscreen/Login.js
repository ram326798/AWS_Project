import React, { Component } from 'react'
import './Login.scss';
import axios from 'axios';

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            renderscreen: 'login',
            lgname: '',
            lgpwd: '',
            rgfname: '',
            rglname: '',
            rgemail: '',
            rglID: '',
            rgdob: '',
            rgnum: '',
            rgpwd: '',
            rgcpwd: '',
            fpname: '',
            fppwd: '',
            fprpwd: '',
            loginerror: '',
            registererror: '',
            forgotpwderror: ''
        };
    }

    condition(screen){
        this.setState({renderscreen: screen});
    }

    onChangeEvent = (e) => {
        let name = e.target.name;
        let val = e.target.value;
        this.setState({[name]: val});
    }

    check(value, type){
        let pattern;
        switch(type){
            case 'name':
                pattern = /^[a-zA-Z0-9]{2,8}/;
                break;
            case 'pwd':
                pattern = /^[a-zA-Z0-9]{2,8}/;
                break;
            case 'mail':
                pattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
                break;
            case 'id':
                pattern = /^[A-Za-z]{6,13}$/;
                break;
            default: 
                break;
        }
        let a = !pattern.test(value);
        return a;
    }
 
    validate = (formName) => {
        switch(formName){
            case 'login': {
                if(this.check(this.state.lgname, 'name') || this.check(this.state.lgpwd, 'pwd')) this.setState({loginerror: 'Enter valid username or password'});
                else {
                    axios.post(`http://107.23.62.141:8081/tweets/signIn`, {
                        "loginId": this.state.lgname,
                        "password": this.state.lgpwd
                    }).then((res)=>{
                        if(res.data) this.props.handleData({'name': this.state.lgname, 'isLogged': 'true'});
                        else this.setState({loginerror: 'Invalid credentials'});
                    }).catch((err)=>{
                        console.log(err);
                        this.setState({loginerror: 'Error: Service Down'});
                    });
                }
                break;
            }
            case 'register': {
                let error;
                if(this.check(this.state.rgfname, 'name')) error = 'Enter valid firstname';
                if(!error && this.check(this.state.rglname, 'name')) error = 'Enter valid Lastname';
                if(!error && this.check(this.state.rgemail, 'mail')) error = 'Enter valid e-mail ID';
                if(!error && this.check(this.state.rglID, 'id')) error = 'Enter valid user ID';
                if(!error && this.state.rgdob === '') error = 'Enter valid DOB';
                if(!error && (this.state.rgnum).length != 10) error = 'Enter valid contact number';
                if(!error && this.state.rgpwd != this.state.rgcpwd) error = 'Enter same passwords in fields';
                if(!error && this.check(this.state.rgpwd, 'pwd') && this.check(this.state.rgcpwd, 'pwd')) error = 'Enter valid password';
                if(!error){
                    axios.post(`http://107.23.62.141:8081/tweets/register`, {
                        "loginId": this.state.rglID,
                        "firstName": this.state.rgfname,
                        "lastName": this.state.rglname,
                        "contactNumber": this.state.rgnum,
                        "dob": this.state.rgdob,
                        "email": this.state.rgemail,
                        "password": this.state.rgpwd
                    }).then((res)=>{
                        let display = '';
                        if(res.data) {
                            display = 'Successfully registered. Redirecting...'
                            setTimeout(() => {
                                this.props.handleData({'name': this.state.rglID, 'isLogged': 'true'});
                            }, 1500);
                        }else display = 'User registeration failed!'
                        this.setState({registererror: display});
                    }).catch((err)=>{
                        console.log(err);
                        this.setState({registererror: 'Error: Service Down'});
                    });
                }
                console.log(error);
                this.setState({registererror: error});
                break;
            }
            case 'forgotpwd': {
                let error;
                if(!error && this.check(this.state.fpname, 'name')) error = 'Invalid username';
                if(!error && this.state.fppwd !== this.state.fprpwd) error = 'Enter same passwords in fields';
                if(!error && this.check(this.state.fppwd, 'pwd') && this.check(this.state.fprpwd, 'pwd')) error = 'Enter valid password';
                if(!error) {
                    axios.put(`http://107.23.62.141:8081/tweets/${this.state.fpname}/forgetPassword/${this.state.fppwd}`)
                    .then((res)=>{
                        if(res.data != 'Invalid credentials') setTimeout(() => window.location.href = '/', 2000);
                        this.setState({forgotpwderror: res.data});
                    }).catch((err)=>{
                        console.log(err);
                        this.setState({forgotpwderror: 'Error: Service Down'});
                    });
                }
                this.setState({forgotpwderror: error});
                break;
            } 
        }
    }

    render() {
        switch(this.state.renderscreen){
            case 'login':
                return (
                    <div className="form">
                    <h2>Login To Your Account</h2>
                    <div className="loginbox">
                        <input placeholder="Username" type="text" name="lgname" id="username" onChange={this.onChangeEvent}/>
                        <input placeholder="Password" type="password" name="lgpwd" id="password" onChange={this.onChangeEvent}/>
                        <p className="error">{this.state.loginerror}</p>
                        <div id="pagelinks">
                            <a href="#" onClick={() => this.condition('forgot')}>Forgot password?</a>
                        </div>
                        <button id="submit" onClick={() => this.validate("login")}>Login</button>
                    </div>
                    <button onClick={() => this.condition('signup')}>Sign Up</button>
                    </div>
                );
            case 'signup':
                return (
                    <div className="form">
                        <h2>Register Your Account</h2>
                        <div className="loginbox">
                            <input placeholder="Firstname" name="rgfname" type="text" id="fname" onChange={this.onChangeEvent}/>
                            <input placeholder="Lastname" name="rglname" type="text" id="lname" onChange={this.onChangeEvent}/>
                            <input placeholder="Email ID" name="rgemail" type="email" id="email" onChange={this.onChangeEvent}/>
                            <input placeholder="Login ID" name="rglID" type="text" id="lID" onChange={this.onChangeEvent}/>
                            <input placeholder="Date of Birth" name="rgdob" type="date" id="dob" onChange={this.onChangeEvent}/>
                            <input placeholder="Contact Number" name="rgnum" type="text" id="number" maxLength="10" onChange={this.onChangeEvent}/>
                            <input placeholder="Enter Password" name="rgpwd" type="password" id="pwd" onChange={this.onChangeEvent}/>
                            <input placeholder="Confirm Password" name="rgcpwd" type="password" id="cpwd" onChange={this.onChangeEvent}/>
                            <p className="error">{this.state.registererror}</p>
                            <button id="submit" onClick={() => this.validate("register")}>Login</button>
                        </div>
                        <div id="pagelinks">
                            <a href="#" onClick={() => this.condition('login')}>Back</a>
                        </div>
                    </div>
                );
            case 'forgot':
                return (
                    <div className="form">
                        <h2>Forgot password?</h2>
                        <div className="loginbox">
                            <input placeholder="Username" name="fpname" type="text" id="fpname" onChange={this.onChangeEvent}/>
                            <input placeholder="Enter new password" name="fppwd" type="password" id="fppwd" onChange={this.onChangeEvent}/>
                            <input placeholder="Re enter password" name="fprpwd" type="password" id="fprpwd" onChange={this.onChangeEvent}/>
                            <p className="error">{this.state.forgotpwderror}</p>
                            <button id="submit" onClick={() => this.validate("forgotpwd")}>Login</button>
                        </div>
                        <div id="pagelinks">
                            <a href="#" onClick={() => this.condition('login')}>Back</a>
                        </div>
                    </div>
                );
            default: 
                return null;
        }
    }
}

export default Login;
