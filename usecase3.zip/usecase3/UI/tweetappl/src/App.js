/* eslint-disable */
import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Redirect} from "react-router-dom";
import Login from './loginscreen/Login';
import Home from './homepage/Home'
import Tweet from './tweetpage/Tweet'
import Display from './displaytweets/Displaytweets'
import 'bootstrap/dist/css/bootstrap.min.css';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
    this.name = '',
    this.searchby = '',
    this.searchtype = '',
    this.usertype = '',
    this.tweetdata = ''
  }

  clearData = () => {
    window.sessionStorage.clear();
    window.sessionStorage.setItem('isLogged', false);
    window.location.href = '/';
  }

  nametweets = (name, type) => {
    if(type !== 'ALL') window.sessionStorage.setItem('searchby', name);
    window.sessionStorage.setItem('searchtype', type);
    window.location.href = '/display';
  }

  getData = (obj) => {
    if(window.sessionStorage.getItem('name') == null){
      let entries = Object.entries(obj);
      entries.forEach(element => {
        window.sessionStorage.setItem(element[0], element[1]);
      });
    }
    window.location.href = '/';
  }

  passshowtweet = (prop) => {
    window.sessionStorage.setItem('usertype', (prop.loginId === this.name) ? 'A' : 'B');
    window.sessionStorage.setItem('tweetdata', JSON.stringify(prop));
    window.location.href = '/viewtweet';
  }

  isLogged = () => {
    this.name =  window.sessionStorage.getItem('name');
    this.searchby =  window.sessionStorage.getItem('searchby');
    this.searchtype =  window.sessionStorage.getItem('searchtype');
    this.usertype =  window.sessionStorage.getItem('usertype');
    this.tweetdata =  window.sessionStorage.getItem('tweetdata');
    return window.sessionStorage.getItem('isLogged') == 'true';
  }

  render(){
    return (
      <Router>
        {this.isLogged() ? <Switch>
            <Route path="/home"><Home clearData={this.clearData} name={this.name} searchname={this.nametweets}/></Route>
            <Route path="/posttweet"><Tweet type="POST" name={this.name}/></Route>
            <Route path="/viewtweet"><Tweet type="VIEW" user={this.usertype} name={this.name} data={JSON.parse(this.tweetdata)} showtweet={this.passshowtweet}/></Route>
            <Route path="/display"><Display name={this.name} searchby={this.searchby} type={this.searchtype} showtweet={this.passshowtweet}/></Route>
            <Redirect to="/home" />
          </Switch> :
          <Switch>
            <Route path="/login"><Login handleData={this.getData}/></Route>
            <Redirect to="/login" />
          </Switch>}
      </Router>
    );
  }
}

export default App;