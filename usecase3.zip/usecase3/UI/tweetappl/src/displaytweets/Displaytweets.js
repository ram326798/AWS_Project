import React, { Component } from 'react';
import './Displaytweets.scss'
import axios from 'axios';

class Displaytweets extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pagedata: ''
        }

        let url = 'http://107.23.62.141:8081/tweets/get/';
        url = (this.props.type === 'NAME') ? `${url}${this.props.searchby}` : `${url}all`;
        axios.get(url).then((res)=>{
                if(res.data) this.setState({pagedata: res.data});
            }).catch((err)=>{
                console.log(err);
                this.setState({searcherror: 'Error: Service Down'});
            });
    }

    render() {
        return (
            <div id="tweetpage" className="displaypage">
                <div className="card mb-3" >
                    <div className="row no-gutters">
                        <div id="leftcontainer" className="col-md-4">
                            <a href="/home">Back</a>
                            <h5 className="card-title">DISPLAY LIST OF TWEETS</h5>
                            
                        </div>
                        <div className="col-md-8" id="rightcontainer">
                            <div className="card-body">
                                <div className="card-text">
                                    <h5 className="card-title">List of tweets</h5>
                                    <p className="card-text"><small className="text-muted">Displaying tweets of : {this.props.type === 'NAME' ? this.props.searchby : 'All Users'}</small></p>
                                    {this.state.pagedata && this.state.pagedata.length !== 0 ?
                                        (<div id="tweet-table">
                                            <table class="table">
                                                <thead id="displaytable">
                                                    <tr>
                                                        <th scope="col">Username</th>
                                                        <th scope="col">Tweet</th>
                                                        <th scope="col">Time Stamp</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                {this.state.pagedata.map(prop => 
                                                    <tr tabIndex="0" onClick={() => this.props.showtweet(prop)}>
                                                        <td>{prop.loginId}</td>
                                                        <td>{prop.tweetMessage}</td>
                                                        <td>{prop.tweetTime}</td>
                                                    </tr>)}
                                                </tbody>
                                            </table>
                                        </div>):
                                        (<p className="error"><small className="text-muted">No records found!</small></p>)
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Displaytweets;
